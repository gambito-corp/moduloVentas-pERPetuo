<?php return array (
  'asignar-controller' => 'App\\Http\\Livewire\\AsignarController',
  'cashout-controller' => 'App\\Http\\Livewire\\CashoutController',
  'categories-controller' => 'App\\Http\\Livewire\\CategoriesController',
  'coins-controller' => 'App\\Http\\Livewire\\CoinsController',
  'company-controller' => 'App\\Http\\Livewire\\CompanyController',
  'permisos-controller' => 'App\\Http\\Livewire\\PermisosController',
  'pos-controller' => 'App\\Http\\Livewire\\PosController',
  'products-controller' => 'App\\Http\\Livewire\\ProductsController',
  'reports-controller' => 'App\\Http\\Livewire\\ReportsController',
  'roles-controller' => 'App\\Http\\Livewire\\RolesController',
  'search-controller' => 'App\\Http\\Livewire\\SearchController',
  'users-controller' => 'App\\Http\\Livewire\\UsersController',
);